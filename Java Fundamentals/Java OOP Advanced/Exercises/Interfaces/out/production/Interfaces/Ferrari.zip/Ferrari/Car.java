package Ferrari;

public interface Car {


    String brakes();
    String gasPedal();



}
