package DefineanInterfacePerson;

public interface Person {


    String getName();

    Integer getAge();

}
