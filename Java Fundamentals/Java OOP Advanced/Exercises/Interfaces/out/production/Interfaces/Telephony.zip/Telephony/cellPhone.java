package Telephony;

public interface cellPhone {


    void call( String number);
    void browse(String website);

}
