package FoodShortage;

public class Food {

    private Integer food;

    public Food(Integer food) {
        this.setFood(food);
    }

    public Integer getFood() {
        return this.food;
    }

    void setFood(Integer food) {
        this.food = food;
    }
}
