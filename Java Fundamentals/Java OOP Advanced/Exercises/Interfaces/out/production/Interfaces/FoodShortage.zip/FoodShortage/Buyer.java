package FoodShortage;

public interface Buyer {


    void buyFood();

    String getName();
    Food getFood();


}
