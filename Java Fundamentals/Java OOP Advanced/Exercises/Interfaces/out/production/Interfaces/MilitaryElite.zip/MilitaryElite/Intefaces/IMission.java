package MilitaryElite.Intefaces;

public interface IMission {


    String getState();
    String getCodeName();

    void CompleteMission();

}
