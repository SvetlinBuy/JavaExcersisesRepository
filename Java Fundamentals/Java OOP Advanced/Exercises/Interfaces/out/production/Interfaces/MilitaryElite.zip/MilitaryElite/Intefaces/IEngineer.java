package MilitaryElite.Intefaces;

import MilitaryElite.Repair;

import java.util.List;

public interface IEngineer extends ISpecialisedSoldier {


  List<Repair> getRepairs();

}
