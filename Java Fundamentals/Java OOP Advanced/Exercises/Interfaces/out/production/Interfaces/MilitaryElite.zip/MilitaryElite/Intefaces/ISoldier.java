package MilitaryElite.Intefaces;

public interface ISoldier {

    String getId();

    String getFirstName();

    String getLastName();

}
