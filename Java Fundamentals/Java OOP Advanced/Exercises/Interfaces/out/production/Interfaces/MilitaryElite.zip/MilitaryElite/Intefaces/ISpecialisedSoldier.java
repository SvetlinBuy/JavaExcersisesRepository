package MilitaryElite.Intefaces;

public interface ISpecialisedSoldier extends IPrivate {



    String getCorps();

}
