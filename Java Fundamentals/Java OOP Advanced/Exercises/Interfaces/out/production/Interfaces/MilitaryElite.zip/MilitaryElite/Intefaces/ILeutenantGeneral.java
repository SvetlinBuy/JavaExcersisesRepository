package MilitaryElite.Intefaces;

import MilitaryElite.Private;

import java.util.List;

public interface ILeutenantGeneral extends IPrivate {

    List<Private> getPrivates();

}
