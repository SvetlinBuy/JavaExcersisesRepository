package MultipleImplementation;

public interface Person {


    String getName();

    Integer getAge();

}
