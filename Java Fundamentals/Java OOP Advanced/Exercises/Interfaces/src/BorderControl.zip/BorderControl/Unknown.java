package BorderControl;

public interface Unknown {

    String getId();

}
