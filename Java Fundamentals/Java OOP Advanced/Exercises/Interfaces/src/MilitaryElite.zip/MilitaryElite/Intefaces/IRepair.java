package MilitaryElite.Intefaces;

public interface IRepair {

    String getRepairPart();
    Integer getRepairHours();

}
