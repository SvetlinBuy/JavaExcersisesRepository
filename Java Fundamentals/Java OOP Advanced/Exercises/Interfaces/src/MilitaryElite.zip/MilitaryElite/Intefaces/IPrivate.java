package MilitaryElite.Intefaces;

public interface IPrivate extends ISoldier {

    Double getSalary();


}
