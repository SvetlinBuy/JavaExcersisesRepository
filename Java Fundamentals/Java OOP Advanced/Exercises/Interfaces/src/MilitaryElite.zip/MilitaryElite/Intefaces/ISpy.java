package MilitaryElite.Intefaces;

public interface ISpy extends ISoldier{

    String getCodeNumber();


}
