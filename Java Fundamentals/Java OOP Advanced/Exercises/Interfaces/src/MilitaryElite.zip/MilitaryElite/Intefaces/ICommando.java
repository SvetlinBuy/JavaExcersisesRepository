package MilitaryElite.Intefaces;

import MilitaryElite.Mission;

import java.util.List;

public interface ICommando {

    List<Mission> getMissionList();


}
