package MooD3;

public class Demon extends Heroes {
    private double energy;

    public Demon(String username, int level, double energy) {
        super(username, level);
        this.energy = energy;
    }

    private double getEnergy() {
        return energy;
    }

    @Override
    protected String generatePassword() {
        return "" + super.getUsername().length() * 217;
    }

    @Override
    public String toString() {
        return String.format("\"%s\" | \"%s\" -> %s\n%.1f",
                this.getUsername(), this.getHashedPassword(), this.getClass().getSimpleName(),this.getEnergy()*this.getLevel());
    }
}
