package MooD3;

public abstract class Heroes implements GameObjects{
    private String username;
    private String hashedPassword;
    private int level;

    public Heroes(String username, int level) {
        this.username = username;
        this.hashedPassword = this.generatePassword();
        this.level = level;
    }

    public String getUsername() {
        return username;
    }

    public String getHashedPassword() {
        return hashedPassword;
    }

    public int getLevel() {
        return level;
    }

    protected abstract String generatePassword();
}
