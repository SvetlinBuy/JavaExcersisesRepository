package MooD3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader read = new BufferedReader(new InputStreamReader(System.in));

        String[] input = read.readLine().split("\\s+\\|\\s+");

        GameObjects go = null;

        String username = input[0];
        String type = input[1];
        int level = Integer.parseInt(input[3]);

        if(type.equalsIgnoreCase("Demon")){
            double energy = Double.parseDouble(input[2]);
            go = new Demon(username,level,energy);

        }else {
            int mana = Integer.parseInt(input[2]);
            go = new Archangel(username,level,mana);
        }
        System.out.println(go);
    }
}
