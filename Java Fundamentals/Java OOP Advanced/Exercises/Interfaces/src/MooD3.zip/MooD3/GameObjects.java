package MooD3;

public interface GameObjects {
}
