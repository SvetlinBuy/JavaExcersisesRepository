package BirthdayCelebrations;

public interface BirthDate {


    String getDate();
}
