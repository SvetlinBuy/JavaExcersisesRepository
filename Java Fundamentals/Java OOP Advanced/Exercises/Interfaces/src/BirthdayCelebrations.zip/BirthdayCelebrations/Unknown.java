package BirthdayCelebrations;

public interface Unknown {

    String getId();

}
