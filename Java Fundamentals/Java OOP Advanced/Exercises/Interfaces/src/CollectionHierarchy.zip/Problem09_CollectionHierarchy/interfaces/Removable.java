package Exercise1_Interfaces.Problem09_CollectionHierarchy.interfaces;

/**
 * Created by bludya on 7/15/16.
 * All rights reserved!
 */
public interface Removable extends Addable {

     String remove();
}
