package OverloadMethod;

public class MathOperation {

    public int add(int one, int two) {

        return one + two;

    }

    public int add(int one, int two, int tree) {

        return one + two + tree;

    }

    public int add(int one, int two, int tree, int four) {

        return one + two + tree + four;

    }

}
