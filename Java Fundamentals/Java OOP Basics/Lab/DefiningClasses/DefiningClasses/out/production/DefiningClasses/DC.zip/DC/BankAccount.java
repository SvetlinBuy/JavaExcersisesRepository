package DC;

public class BankAccount {

    public BankAccount(int id) {
        this.id = id;
        this.balance = 0;
    }

    private  int id;
    private  double balance;


     void deposit(double amount) {


        if(amount >= 0){
            this.balance += amount;
        }

    }

     void withdraw(double amount) {
        if (this.balance - amount >=  0) {
            this.balance -= amount;
        }else {
            System.out.println("Insufficient balance");
        }
    }

    public double getBalance() {
        return this.balance;
    }

    @Override
    public String toString() {
        return "ID" + this.id;
    }
}
