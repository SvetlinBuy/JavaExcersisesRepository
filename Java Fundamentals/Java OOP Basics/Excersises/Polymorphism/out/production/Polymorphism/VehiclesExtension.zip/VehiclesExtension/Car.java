package VehiclesExtension;


 class Car extends Vehicle {


     Car(double quantity, double consumption, double tankCapcity) {
        super(quantity, consumption, tankCapcity);
    }



}
