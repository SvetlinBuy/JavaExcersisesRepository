package VehiclesExtension;


public class Bus extends Vehicle {
     Bus(double quantity, double consumption, double tankCapacity) {
        super(quantity, consumption, tankCapacity);
    }

}
