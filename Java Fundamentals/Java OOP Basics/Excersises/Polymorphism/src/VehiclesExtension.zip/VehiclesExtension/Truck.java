package VehiclesExtension;


 class Truck extends Vehicle {

     Truck(double quantity, double consumption, double tankCapacity) {
        super(quantity, consumption, tankCapacity);
    }


}
