package VehiclesExtension;

public class Bus extends Vehicle {
    public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity);
    }

    @Override
    protected void setFuelConsumption(double fuelConsumption) {
        super.setFuelConsumption(fuelConsumption + 1.4);
    }

    @Override
    public void driveEmpty(double distance) {
        double neededFuel = distance * (this.getFuelConsumption() - 1.4);

        if (neededFuel > this.getFuelQuantity()) {
            throw new IllegalArgumentException(this.getClass().getSimpleName() + " needs refueling");
        }

        super.setFuelQuantity(this.getFuelQuantity() - neededFuel);
        super.printMessage(this.getClass().getSimpleName(), distance);
    }
}
