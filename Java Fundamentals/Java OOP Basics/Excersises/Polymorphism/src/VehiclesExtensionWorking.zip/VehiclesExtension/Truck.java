package VehiclesExtension;

public class Truck extends Vehicle {
    public Truck(double fuelQuantity, double fuelConsumption, double tankCapacity) {

        super(fuelQuantity, (fuelConsumption), tankCapacity);
    }

    @Override
    protected void setFuelConsumption(double fuelConsumption) {
        super.setFuelConsumption(fuelConsumption + 1.6);
    }

    @Override
    public void refill(double fuelQuantity) {
        super.refill(fuelQuantity * 0.95);
    }
}
