package VehiclesExtension;

import java.text.DecimalFormat;

abstract class Vehicle {
    private double fuelQuantity;
    private double fuelConsumption;
    private double tankCapacity;

    public Vehicle(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        this.setTankCapacity(tankCapacity);
        this.setFuelQuantity(fuelQuantity);
        this.setFuelConsumption(fuelConsumption);
    }

    public double getFuelQuantity() {
        return fuelQuantity;
    }

    protected void setFuelQuantity(double fuelQuantity) {
        if (fuelQuantity <= 0.0) {
            throw new IllegalArgumentException("Fuel must be a positive number");

        } else if (fuelQuantity > this.getTankCapacity()) {
            throw new IllegalArgumentException("Cannot fit fuel in tank");

        }
        this.fuelQuantity = fuelQuantity;
    }

    public double getFuelConsumption() {
        return fuelConsumption;
    }

    public double getTankCapacity() {
        return tankCapacity;
    }

    private void setTankCapacity(double tankCapacity) {
        this.tankCapacity = tankCapacity;
    }

    protected void setFuelConsumption(double fuelConsumption) {

        this.fuelConsumption = fuelConsumption;
    }

    public void drive(double distance) {
        double neededFuel = distance * this.getFuelConsumption();

        if (neededFuel > this.getFuelQuantity()) {
            throw new IllegalArgumentException(this.getClass().getSimpleName() + " needs refueling");
        }

        this.setFuelQuantity(this.getFuelQuantity() - neededFuel);
        printMessage(this.getClass().getSimpleName(), distance);

    }
    public void driveEmpty(double distance){

    }

    public void refill(double fuelQuantity) {

        if (fuelQuantity <= 0.0) {
            throw new IllegalArgumentException("Fuel must be a positive number");

        }
        this.setFuelQuantity(this.getFuelQuantity() + fuelQuantity);
    }

    protected void printMessage(String simpleName, double distance) {
        DecimalFormat df = new DecimalFormat("#.##");
        System.out.println(simpleName + " travelled " + df.format(distance) + " km");
    }
}
