package VehiclesExtension;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;

public class Main {
    private static Map<String, Vehicle> autoPark = new LinkedHashMap<>();

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        for (int i = 1; i <= 3; i++) {
            String[] input = reader.readLine().split("\\s+");
            try {
                readVehicle(input);
            } catch (IllegalArgumentException iag) {
                System.out.println(iag.getMessage());
            }
        }

        int num = Integer.parseInt(reader.readLine());

        for (int i = 0; i < num; i++) {
            String[] tokens = reader.readLine().split("\\s+");

            String action = tokens[0];
            String vehicle = tokens[1];
            double amount = Double.parseDouble(tokens[2]);
            try {
                switch (action) {
                    case "Drive":
                        autoPark.get(vehicle).drive(amount);
                        break;
                    case "Refuel":
                        autoPark.get(vehicle).refill(amount);
                        break;
                    case "DriveEmpty":
                        autoPark.get(vehicle).driveEmpty(amount);
                        break;
                }
            } catch (IllegalArgumentException iag) {
                System.out.println(iag.getMessage());
            }
        }
        System.out.println(String.format("Car: %.2f", autoPark.get("Car").getFuelQuantity()));
        System.out.println(String.format("Truck: %.2f", autoPark.get("Truck").getFuelQuantity()));
        System.out.println(String.format("Bus: %.2f", autoPark.get("Bus").getFuelQuantity()));

    }

    private static void readVehicle(String[] input) {
        String vehicleType = input[0];
        double fuelQuantity = Double.parseDouble(input[1]);
        double fuelConsumption = Double.parseDouble(input[2]);
        double tankCapacity = Double.parseDouble(input[3]);

        switch (vehicleType) {
            case "Car":
                Vehicle car = new Car(fuelQuantity, fuelConsumption, tankCapacity);
                autoPark.putIfAbsent(vehicleType, car);
                break;
            case "Truck":
                Vehicle truck = new Truck(fuelQuantity, fuelConsumption, tankCapacity);
                autoPark.put(vehicleType, truck);
                break;
            case "Bus":
                Vehicle bus = new Bus(fuelQuantity, fuelConsumption, tankCapacity);
                autoPark.put(vehicleType, bus);
                break;
        }
    }
}
