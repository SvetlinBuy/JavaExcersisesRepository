package Vehicles;


public class Truck extends Vehicle {

    public Truck(double quantity, double consumption) {
        super(quantity, consumption);
    }

}
