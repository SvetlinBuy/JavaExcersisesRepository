package Vehicles;


public class Car extends Vehicle {


    public Car(double quantity, double consumption) {
        super(quantity, consumption);
    }

}
