package DefiningClasessExercises.Google;
 
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
 
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Map<String, Person> people = new HashMap<>();
        while (true) {
            String line = reader.readLine();
            if (line.equals("End")) {
                break;
            }
            String[] tokens = line.split(" ");
            people.putIfAbsent(tokens[0], new Person());
            if (tokens[1].equals("company")) {
                people.get(tokens[0]).company = new Person.Company(tokens[2], tokens[3], Double.parseDouble(tokens[4]));
            } else if (tokens[1].equals("car")) {
                people.get(tokens[0]).car = new Person.Car(tokens[2], tokens[3]);
            } else if (tokens[1].equals("parents")) {
                people.get(tokens[0]).parentsList.add(new Person.Parents(tokens[2], tokens[3]));
            } else if (tokens[1].equals("children")) {
                people.get(tokens[0]).childrenList.add(new Person.Children(tokens[2], tokens[3]));
            } else {
                people.get(tokens[0]).pokemonList.add(new Person.Pokemon(tokens[2], tokens[3]));
            }
        }
        String name = reader.readLine();
        Person toPrint = people.get(name);
        System.out.println(name);
        System.out.println(toPrint);
    }
}