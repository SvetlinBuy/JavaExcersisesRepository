package DefiningClasessExercises.Google;
 
import java.util.ArrayList;
import java.util.List;
 
class Person {
    public Company company;
    public List<Pokemon> pokemonList = new ArrayList<>();
    public List<Parents> parentsList = new ArrayList<>();
    public List<Children> childrenList = new ArrayList<>();
    public Car car;
 
    public Person() {
    }
 
    public Person(Company company) {
        this.company = company;
    }
 
 
    public static class Company {
        private String companyName;
        private String department;
        private double salary;
 
        public Company(String companyName, String department, double salary) {
            this.companyName = companyName;
            this.department = department;
            this.salary = salary;
        }
    }
 
    public static class Pokemon {
        private String pokemonName;
        private String pokemonType;
 
        public Pokemon(String pokemonName, String pokemonType) {
            this.pokemonName = pokemonName;
            this.pokemonType = pokemonType;
        }
    }
 
    public static class Parents {
        private String parentsName;
        private String parentsBirthday;
 
        public Parents(String parentsName, String parentsBirthday) {
            this.parentsName = parentsName;
            this.parentsBirthday = parentsBirthday;
        }
    }
 
    public static class Children {
        private String childName;
        private String childBirthday;
 
        public Children(String childName, String childBirthday) {
            this.childName = childName;
            this.childBirthday = childBirthday;
        }
    }
 
    public static class Car {
        private String carName;
        private String carSpeed;
 
        public Car(String carName, String carSpeed) {
            this.carName = carName;
            this.carSpeed = carSpeed;
        }
    }
 
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Company:\n");
        if (this.company != null) {
            sb.append(this.company.companyName).append(" ")
                    .append(this.company.department).append(" ").append(String.format("%.2f", this.company.salary)).append("\n");
        }
        sb.append("Car:\n");
        if (this.car != null) {
            sb.append(this.car.carName).append(" ").append(this.car.carSpeed).append("\n");
        }
        sb.append("Pokemon:\n");
        if (!this.pokemonList.isEmpty()) {
            for (Pokemon pokemon : pokemonList) {
                sb.append(pokemon.pokemonName).append(" ").append(pokemon.pokemonType).append("\n");
            }
        }
        sb.append("Parents:\n");
        if (!this.parentsList.isEmpty()) {
            for (Parents parents : parentsList) {
                sb.append(parents.parentsName).append(" ").append(parents.parentsBirthday).append("\n");
            }
        }
        sb.append("Children:\n");
        if (!this.childrenList.isEmpty()) {
            for (Children children : childrenList) {
                sb.append(children.childName).append(" ").append(children.childBirthday).append("\n");
            }
        }
        return sb.toString();
    }
}