package pokemon_trainer;
 
import java.util.List;
import java.util.stream.Collectors;
 
public class Trainer {
    private static final int DEFAULT_BADGES = 0;
    private String name;
    private List<Pokemon> pokemons;
    private int numberOfBadges;
 
    public Trainer(String name, List<Pokemon> pokemons) {
        this.name = name;
        this.pokemons = pokemons;
        this.numberOfBadges = DEFAULT_BADGES;
    }
 
    public List<Pokemon> getPokemons() {
        return this.pokemons;
    }
 
    public void setPokemons(List<Pokemon> pokemons) {
        this.pokemons = pokemons;
    }
 
    public int getNumberOfBadges() {
        return this.numberOfBadges;
    }
 
    public void increaseBadges(){
        this.numberOfBadges++;
    }
 
    public void decreasePokemonsHealth(){
        this.pokemons.forEach(p -> p.setHealth(p.getHealth() - 10));
        List<Pokemon> pmons = this.getPokemons().stream().filter(p -> p.getHealth() > 0).collect(Collectors.toList());
        this.setPokemons(null);
        this.setPokemons(pmons);
    }
 
    @Override
    public String toString() {
        return String.format("%s %d %d", this.name, this.numberOfBadges, this.getPokemons().size());
    }
}