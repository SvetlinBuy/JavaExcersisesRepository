package pokemon_trainer;
 
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
 
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Map<String, Trainer> trainers = new LinkedHashMap<>();
        while(true){
            String[]tokens = reader.readLine().split("\\s+");
            Trainer trainer = null;
            if("Tournament".equalsIgnoreCase(tokens[0])){
                break;
            }
            Pokemon pokemon = new Pokemon(tokens[1], tokens[2], Integer.parseInt(tokens[3]));
            if(!trainers.containsKey(tokens[0])){
                trainer = new Trainer(tokens[0], new ArrayList<>());
                trainers.put(tokens[0], trainer);
            }
            trainers.get(tokens[0]).getPokemons().add(pokemon);
        }
 
        while(true){
            String elementInput = reader.readLine();
            if("End".equalsIgnoreCase(elementInput)){
                break;
            }
            trainers.entrySet().stream().filter(t -> checkPokemonElements(t, elementInput)).forEach(t -> t.getValue().increaseBadges());
            trainers.entrySet().stream().filter(t -> checkPokemonElements2(t, elementInput)).forEach(t -> t.getValue().decreasePokemonsHealth());
        }
 
        trainers.entrySet().stream().sorted((t1, t2) -> compare(t1, t2)).forEach(t -> System.out.println(t.getValue()));
 
    }
 
    private static int compare(Map.Entry<String, Trainer> t1, Map.Entry<String, Trainer> t2) {
        if(t1.getValue().getNumberOfBadges() <= t2.getValue().getNumberOfBadges()){
            return 0;
        }else{
            return -1;
        }
    }
 
    private static boolean checkPokemonElements(Map.Entry<String, Trainer> t, String elementInput) {
        List<Pokemon> opkemonsToCheck = t.getValue().getPokemons();
        boolean contains = false;
        for (Pokemon pokemon : opkemonsToCheck) {
            if(pokemon.getElement().equalsIgnoreCase(elementInput)){
                contains = true;
                break;
            }
        }
        return contains;
    }
    private static boolean checkPokemonElements2(Map.Entry<String, Trainer> t, String elementInput) {
        List<Pokemon> opkemonsToCheck = t.getValue().getPokemons();
        List<String> elements = new ArrayList<>();
        for (Pokemon pokemon : opkemonsToCheck) {
            elements.add(pokemon.getElement());
        }
        if(!elements.contains(elementInput)){
            return true;
        }else{
            return false;
        }
    }
}