package ShoppingSpree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader read = new BufferedReader(new InputStreamReader(System.in));

        List<Person> personList = new ArrayList<>();
        List<Product> productList = new ArrayList<>();

        String[] personInput = read.readLine().split(";");
        String[] productInput = read.readLine().split(";");

        try{
            for (String person_money : personInput) {
                String name = person_money.split("=")[0];
                double money = Double.parseDouble(person_money.split("=")[1]);
                    Person person = new Person(name, money);
                    personList.add(person);

            }

            for (String product_cost : productInput) {
                String productName = product_cost.split("=")[0];
                double cost = Double.parseDouble(product_cost.split("=")[1]);

                    Product product = new Product(productName, cost);
                    productList.add(product);

            }

            while (true) {
                String[] input = read.readLine().split("\\s+");
                if ("END".equalsIgnoreCase(input[0])) {
                    break;
                }
                String name = input[0];
                String product = input[1];

                trade(name, product, personList, productList);
            }

            for (Person person : personList) {
                System.out.println(person);
            }
        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }


    }

    private static void trade(String name, String product, List<Person> personList, List<Product> productList) {
        for (Person person : personList) {
            if (person.getName().equals(name)) {
                for (Product productName : productList) {
                    if (productName.getName().equals(product)) {
                        if (person.hasEnoughMoney(productName)) {
                            person.buyProduct(productName);
                            System.out.printf("%s bought %s\n", name, product);
                        } else {
                            System.out.printf("%s can't afford %s\n", name, product);
                        }
                    }
                }
            }
        }
    }
}
