package ShoppingSpree;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Person {
    private String name;
    private double money;
    private List<Product> productList;

    public Person(String name, double money) {
        setName(name);
        setMoney(money);
        this.productList = new ArrayList<>();
    }

    public boolean hasEnoughMoney(Product product) {
        return this.money >= product.getCost();
    }

    public void buyProduct(Product product) {
        this.money -= product.getCost();
        this.productList.add(product);
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.trim().isEmpty() || name == null) {
            throw new IllegalArgumentException("Name cannot be empty");
        }
        this.name = name;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        if (money < 0) {
            throw new IllegalArgumentException("Money cannot be negative");
        }
        this.money = money;
    }

    @Override
    public String toString() {
        return String.format("%s - %s", this.name, this.productList.size() == 0 ?
                "Nothing bought" :
                this.productList.stream().map(product -> product.getName()).collect(Collectors.joining(", ")));
    }
}

